Many thanks to supporters of the BFG!
-----

Contribute towards the open-source development of the BFG on [**BountySource**](https://www.bountysource.com/teams/bfg-repo-cleaner)

* [Thomas Ferris Nicolaisen](http://www.tfnico.com/) - host of the excellent [GitMinutes](http://www.gitminutes.com) podcast
* [Alec Clews](https://alecthegeek.github.io/)
* [ramtej](https://github.com/ramtej)
